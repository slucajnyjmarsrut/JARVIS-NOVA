# -*- coding: utf-8 -*-
"""JARVIS NOVA Python Agent — one-window desktop assistant."""
import os, queue, sys, threading, tkinter as tk
from tkinter import messagebox, simpledialog, ttk
from agent_core import Plan, parse_local, validate_plan, ask_ai_for_plan
from desktop import Desktop, AppSuggestion
from speaker import Speaker
from voice_engine import Voice
from self_improve import LearningStore, safe_name
from trimodal_service import TrimodalService
from voice_engine import Voice as RC4Voice

class Jarvis(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("JARVIS NOVA — Agent")
        self.geometry("650x460")
        self.minsize(510,350)
        self.configure(bg="#101726")
        self.protocol("WM_DELETE_WINDOW",self.close)
        self.q=queue.Queue()
        self.voice_enabled=False
        self._closing=False
        self._shutdown=threading.Event()
        self.executing=False
        self.control_allowed=False
        self.vision_allowed=False
        self.engine="none"
        self.learning=LearningStore()
        self._pending_alias=None
        self.speaker=Speaker()
        self.trimodal=TrimodalService()
        self.desktop=Desktop(lambda:self.control_allowed,lambda:self.vision_allowed,
                             learning=self.learning)
        self.voice=RC4Voice(lambda s:self.q.put(("heard",s)),
                            lambda s:self.q.put(("status",s)),
                            lambda:self.speaker.busy or self.trimodal.speaking,
                            on_vision_audio=lambda pcm,src:self.q.put(("vision_audio",(pcm,src))))
        style=ttk.Style(self)
        style.theme_use("clam")
        style.configure("Jarvis.TButton",padding=6)
        header=tk.Label(self,text="JARVIS NOVA",font=("Segoe UI",22,"bold"),
                         fg="#b5d9ff",bg="#101726")
        header.pack(anchor="w",padx=24,pady=(18,4))
        self.status=tk.StringVar(value="Запускаю офлайн-голос…")
        label=tk.Label(self,textvariable=self.status,font=("Segoe UI",10),
                       fg="#93aecb",bg="#101726")
        label.pack(anchor="w",padx=26,pady=(0,14))
        self.history=tk.Text(self,wrap="word",height=12,bg="#18243a",fg="#eef4ff",
                             insertbackground="white",relief="flat",font=("Segoe UI",11),
                             padx=15,pady=12,state="disabled")
        self.history.pack(fill="both",expand=True,padx=24)
        bottom=tk.Frame(self,bg="#101726")
        bottom.pack(fill="x",padx=24,pady=(12,20))
        self.entry=tk.Entry(bottom,bg="#18243a",fg="white",insertbackground="white",
                            relief="flat",font=("Segoe UI",11))
        self.entry.pack(fill="x",expand=True,ipady=9)
        self.entry.bind("<Return>",self.enter)
        self.bind("<F9>",self.f9)
        # Permissions, engine configuration and stop live in native menus,
        # not as an extra control panel on the main screen.
        menu=tk.Menu(self)
        permissions=tk.Menu(menu,tearoff=False)
        permissions.add_command(label="Разрешить управление компьютером",command=self.grant_control)
        permissions.add_command(label="Разрешить зрение для старых команд (только локально)",command=self.grant_vision)
        permissions.add_command(label="Отозвать все разрешения",command=self.revoke)
        menu.add_cascade(label="Разрешения",menu=permissions)
        vision_menu=tk.Menu(menu,tearoff=False)
        vision_menu.add_command(label="Спросить голосом об экране (Whisper → Vision → Silero)",
                                command=lambda:self.request_trimodal("screen"))
        vision_menu.add_command(label="Спросить голосом о камере (Whisper → Vision → Silero)",
                                command=lambda:self.request_trimodal("camera"))
        menu.add_cascade(label="Зрение",menu=vision_menu)
        ai=tk.Menu(menu,tearoff=False)
        for title,choice in [("Офлайн-команды","none"),("Локальная Ollama","ollama"),
                             ("OpenAI API (нужен ключ)","openai"),
                             ("Claude API (нужен ключ)","anthropic")]:
            ai.add_command(label=title,command=lambda v=choice:self.set_engine(v))
        menu.add_cascade(label="AI",menu=ai)
        learning_menu=tk.Menu(menu,tearoff=False)
        learning_menu.add_command(label="Научить названию программы…",command=self.teach_alias)
        learning_menu.add_command(label="Показать результаты обучения",command=self.learning_report)
        learning_menu.add_command(label="Удалить выученное название…",command=self.remove_alias)
        learning_menu.add_command(label="Сбросить обучение",command=self.reset_learning)
        learning_menu.add_command(label="Проверить офлайн-модели",command=self.check_models)
        menu.add_cascade(label="Самоулучшение",menu=learning_menu)
        menu.add_command(label="Стоп/Выключить микрофон",command=self.toggle_voice)
        self.config(menu=menu)
        self.log("Система","Управление голосом: «Джарвис, открой Chrome». F9 — ручная активация.")
        self.after(100,self.pump)
        threading.Thread(target=self.init_voice,daemon=True).start()

    def log(self,person,message):
        self.history.configure(state="normal")
        self.history.insert("end",f"{person}: {message}\n\n")
        self.history.see("end")
        self.history.configure(state="disabled")

    def init_voice(self):
        # Microphone starts independently of slow PyTorch/Silero loading.
        if self._shutdown.is_set():
            return
        self.voice.start()
        if self._shutdown.is_set():
            self.voice.stop()
            return
        self.voice_enabled=True
        self.q.put(("status","Микрофон запускается · жду «Джарвис»"))
        message=self.speaker.load()
        if not self._shutdown.is_set():
            self.q.put(("status",message))

    def f9(self,event=None):
        if self.voice_enabled:self.voice.activate()
        return "break"

    def toggle_voice(self):
        if self._closing:return
        if self.voice_enabled:
            self.voice.stop();self.voice_enabled=False
            self.status.set("Микрофон выключен")
        else:
            self.voice.start();self.voice_enabled=True
            self.status.set("Включаю микрофон…")

    def grant_control(self):
        if messagebox.askyesno("Разрешение","Разрешить JARVIS управлять мышью, клавиатурой и окнами до закрытия приложения?"):
            self.control_allowed=True
            self.status.set("Управление разрешено до закрытия JARVIS")

    def grant_vision(self):
        if messagebox.askyesno("Разрешение","Разрешить захватывать текущий экран в оперативную память и отправлять кадры только в локальную Ollama?"):
            self.vision_allowed=True
            self.status.set("Локальное зрение разрешено до закрытия JARVIS")

    def revoke(self):
        self.control_allowed=False;self.vision_allowed=False
        self.status.set("Все разрешения отозваны")

    def teach_alias(self):
        spoken=simpledialog.askstring("Обучение JARVIS", "Как ты называешь программу голосом?",parent=self)
        if spoken is None:return
        if not safe_name(spoken):
            messagebox.showerror("Ошибка", "Название содержит недопустимые символы.",parent=self)
            return
        official=simpledialog.askstring("Обучение JARVIS",
            "Какое ТОЧНОЕ имя этой программы в меню Пуск?\nНапример: Google Chrome",parent=self)
        if official is None:return
        if not self.desktop.is_installed(official):
            messagebox.showwarning("Программа не найдена",
                "В меню Пуск нет программы с таким точным названием. Обучение отменено.",parent=self)
            return
        if not messagebox.askyesno("Подтверждение",
            f"Запомнить, что «{spoken}» означает «{official}»?",parent=self):
            return
        try:
            self.learning.learn(spoken,official,verified=True)
            self.log("JARVIS",f"Запомнил: «{spoken}» → «{official}».")
        except Exception as exc:
            messagebox.showerror("Ошибка обучения",str(exc),parent=self)

    def remove_alias(self):
        spoken=simpledialog.askstring("Забыть название", "Какое выученное название удалить?",parent=self)
        if spoken is not None:
            if self.learning.unlearn(spoken):
                self.log("JARVIS","Выученное название удалено.")
            else:
                self.log("JARVIS","Такого выученного названия нет.")

    def learning_report(self):
        messagebox.showinfo("Самоулучшение JARVIS",self.learning.summary(),parent=self)

    def reset_learning(self):
        if messagebox.askyesno("Сброс обучения",
            "Удалить все выученные названия и счётчики ошибок?",parent=self):
            self.learning.reset()
            self.log("JARVIS","Локальное обучение сброшено.")

    def check_models(self):
        from speaker import assets
        root=assets()
        models={"Vosk":root/"vosk"/"am"/"final.mdl",
                "Whisper":root/"base.pt","Silero":root/"v5_ru.pt"}
        lines=[f"{name}: {'файлы найдены' if path.is_file() else 'не встроен'}"
               for name,path in models.items()]
        from bundled_vision_runtime import validate_offline_model_store
        try:
            validate_offline_model_store(root.parent)
            if not (root.parent/"ollama"/"ollama.exe").is_file():
                raise FileNotFoundError("нет переносимого ollama.exe")
            lines.append("Vision: локальные файлы найдены (инференс не проверен)")
        except Exception as exc:
            lines.append("Vision: автономная модель/движок отсутствует ("+str(exc)[:80]+")")
        lines.append("Это проверка файлов, а не реальный запуск нейросетей.")
        messagebox.showinfo("Проверка движков","\n".join(lines),parent=self)

    def set_engine(self,engine):
        self.engine=engine
        self.status.set({"none":"Офлайн-команды","ollama":"AI: локальная Ollama",
                         "openai":"AI: OpenAI API (ключ из окружения)",
                         "anthropic":"AI: Claude API (ключ из окружения)"}[engine])

    def enter(self,event=None):
        s=self.entry.get().strip()
        self.entry.delete(0,"end")
        if s:self.handle_text(s)

    def handle_text(self,text):
        if self._closing:return
        self.log("Вы",text)
        source=self.voice.vision_source(text)
        if source:
            # A typed vision request starts one five-second spoken Whisper question.
            # Wake-word audio uses the same original PCM via on_vision_audio.
            self.request_trimodal(source)
            return
        if text.casefold().strip() in {"стоп","отмена","прекрати"}:
            self.status.set("Остановлено")
            return
        local=parse_local(text)
        if self.engine=="none" or local.steps or local.answer or text.casefold().strip() in {"открой","запусти","включи"}:
            self.execute_plan(local)
        else:
            self.status.set("Обдумываю запрос…")
            def worker():
                plan=ask_ai_for_plan(text,self.engine)
                self.q.put(("plan",plan))
            threading.Thread(target=worker,daemon=True).start()

    def request_trimodal(self, source: str, audio_pcm: bytes | None = None):
        if self._closing or self.executing:return
        if source not in {"camera","screen"}:return
        noun="камеры" if source=="camera" else "экрана"
        if not messagebox.askyesno("Разрешение на изображение",
            f"Разрешить JARVIS захватить ОДИН кадр {noun} и обработать его локально? "
            "Изображение не будет отправлено в облако.",parent=self):
            self.status.set("Анализ изображения отменён")
            return
        self.executing=True
        self.status.set("Подготавливаю реальные Whisper, Vision и Silero…")
        def worker():
            restart=self.voice_enabled
            try:
                # Release microphone before Stage 2 opens it (PortAudio cannot
                # reliably host overlapping streams on Bluetooth headsets).
                if restart:self.voice.stop()
                self.trimodal.initialize()
                if self._shutdown.is_set():return
                if audio_pcm is None:
                    self.q.put(("status","Скажите вопрос вслух: запись 5 секунд…"))
                    samples=None
                else:
                    import numpy as np
                    samples=np.frombuffer(audio_pcm,dtype="<i2").astype(np.float32)/32768.0
                result=self.trimodal.run_once(
                    source=source, camera_consent=source=="camera",
                    screen_consent=source=="screen", seconds=5.0,
                    audio_samples=samples, sample_rate=16000)
                if not self._shutdown.is_set():
                    self.q.put(("trimodal_result",(True,result)))
            except Exception as exc:
                if not self._shutdown.is_set():
                    self.q.put(("trimodal_result",(False,f"{type(exc).__name__}: {exc}")))
            finally:
                if restart and not self._shutdown.is_set():
                    self.voice.start()
                if not self._shutdown.is_set():
                    self.q.put(("trimodal_complete",None))
        threading.Thread(target=worker,daemon=True,name="jarvis-trimodal").start()

    def execute_plan(self,plan):
        if self.executing:
            self.reply("Подожди, пока завершится предыдущая команда.")
            return
        try: plan=validate_plan(plan)
        except Exception as exc:
            self.reply("Команда отклонена: "+str(exc));return
        if plan.question:self.reply(plan.question);return
        if plan.answer:self.reply(plan.answer);return
        if not plan.steps:self.reply("Не понял, что требуется.");return
        if any(s.kind=="screen_describe" for s in plan.steps):
            if len(plan.steps)>1:
                self.reply("Анализ экрана выполняется отдельно от остальных действий.")
                return
            self.request_trimodal("screen")
            return
        if any(s.kind not in {"screen_describe","window_status","open_app","open_url"} for s in plan.steps):
            if not self.control_allowed:
                self.reply("Сначала разреши управление компьютером через меню «Разрешения».");return
        # AI plans always need human confirmation; risky deterministic commands too.
        # Preserve the intended target before the confirmation window steals focus.
        target=None
        if any(s.kind=="close_window" for s in plan.steps):
            try: target=self.desktop.active_window()
            except Exception as exc:
                self.reply("Не удалось определить окно: "+str(exc));return
        if plan.need_confirmation:
            actions=", ".join(s.kind+(" "+s.value[:45] if s.value else "") for s in plan.steps)
            if not messagebox.askyesno("Подтвердить действие",
                                        "JARVIS собирается выполнить:\n"+actions+"\n\nПродолжить?"):
                self.reply("Действие отменено.");return
        self.executing=True
        self.status.set("Выполняю команду…")
        def worker():
            self.desktop._active_override=target
            try:
                results=[]
                for step in plan.steps:
                    results.append(self.desktop.run(step))
                self.q.put(("action_result", (True,". ".join(results),
                                                tuple(x.kind for x in plan.steps))))
            except AppSuggestion as suggestion:
                self.q.put(("app_suggestion", (suggestion.spoken,suggestion.installed)))
            except Exception as exc:
                self.q.put(("action_result", (False,"Не получилось: "+str(exc)[:250],
                                                tuple(x.kind for x in plan.steps))))
            finally:
                self.desktop._active_override=None
        threading.Thread(target=worker,daemon=True,name="jarvis-action").start()

    def reply(self,s):
        if self._closing:return
        self.log("JARVIS",s)
        self.status.set(s[:100])
        threading.Thread(target=self.speaker.say,args=(s,),daemon=True).start()

    def pump(self):
        if self._closing:return
        try:
            while True:
                op,val=self.q.get_nowait()
                if op=="heard":self.handle_text(val)
                elif op=="vision_audio":
                    pcm,src=val
                    self.request_trimodal(src,audio_pcm=pcm)
                elif op=="trimodal_result":
                    success,result=val
                    if success:
                        if result.transcript:self.log("Whisper",result.transcript)
                        self.log("JARVIS",result.answer or "Whisper не обнаружил речи")
                        self.status.set("Трёхмодельный цикл завершён" if result.answer else "Речь не обнаружена")
                    else:
                        self.log("Ошибка трёхмодельного цикла",result)
                        self.status.set("Ошибка Whisper/Vision/Silero — подробности в журнале")
                elif op=="trimodal_complete":
                    self.executing=False
                elif op=="status":self.status.set(val)
                elif op=="plan":self.execute_plan(val)
                elif op=="action_result":
                    self.executing=False
                    success,text,kinds=val
                    for kind in kinds:
                        self.learning.feedback(kind,success)
                    if self._pending_alias:
                        spoken,official=self._pending_alias
                        self._pending_alias=None
                        if success and self.desktop.is_installed(official):
                            try:
                                self.learning.learn(spoken,official,verified=True)
                                text+=f". Запомнил название «{spoken}» на будущее."
                            except Exception as exc:
                                text+=f". Не смог сохранить название: {exc}"
                    self.reply(text)
                elif op=="app_suggestion":
                    self.executing=False
                    spoken,installed=val
                    if self.desktop.is_installed(installed) and messagebox.askyesno(
                        "Самоулучшение JARVIS",
                        f"Я не нашёл «{spoken}».\nВозможно, ты имел в виду «{installed}»?\n\n"
                        "Если программа запустится, я запомню название для следующего раза.",parent=self):
                        self._pending_alias=(spoken,installed)
                        from agent_core import Step, Plan
                        self.execute_plan(Plan(steps=[Step("open_app",installed)]))
                    else:
                        self.reply("Не запускаю программу без подтверждения. Можно научить меня через меню «Самоулучшение».")
        except queue.Empty:pass
        self.after(100,self.pump)

    def close(self):
        # WM_DELETE_WINDOW is a *complete exit*, never "hide to tray".
        if self._closing:return
        self._closing=True
        self._shutdown.set()  # prevent slow model initialization reopening the mic
        self.voice_enabled=False
        self.control_allowed=False;self.vision_allowed=False
        self.voice.stopping=True
        self.voice.running=False
        # Stop resources without freezing the GUI on PortAudio or Vosk teardown.
        def stop_resources():
            try:self.voice.stop()
            except Exception:pass
            try:self.speaker.shutdown()
            except Exception:pass
            try:self.trimodal.shutdown()
            except Exception:pass
        threading.Thread(target=stop_resources,daemon=True,name="jarvis-exit-cleanup").start()
        # Bounded fail-safe: GPU/audio native libraries may leave non-daemon threads.
        # This fires only if the interpreter is still running 5s after closing.
        watchdog=threading.Timer(5.0,lambda:os._exit(0))
        watchdog.daemon=True
        watchdog.start()
        self.destroy()

if __name__=="__main__":
    if sys.platform!="win32":
        print("Это приложение предназначено для Windows.")
    Jarvis().mainloop()
